import gym # OpenAI gym
import glfw
#from gym import envs
#import time
#import os

#os.add_dll_directory("C://Users//mtt//.mujoco//mujoco210//bin")


# Para visualizar que es lo que hace el agente
glfw.init()

test_steps = 1000

env = gym.make("Reacher-v2") # brazo 2 DOF
observation, info = env.reset(seed=0, return_info=True)
print(observation)

for _ in range(test_steps):
    env.render()
    accion = env.action_space.sample()
    #env.step(acccion) # take a random action
    observation, reward, done, aux_dict = env.step(accion)
    #time.sleep(0.1)
     
    # Control (con red ya entrenada)
    # (obs) -->NN--> accion
    
    # Training 
    # (obs, reward) -->NN--> accion
    print(observation)
    
glfw.terminate()
env.close()
