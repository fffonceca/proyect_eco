import gym # OpenAI Gym
#from gym import envs
#import os

#os.add_dll_directory("C://Users//mtt//.mujoco//mujoco210//bin")

test_steps = 1000

env = gym.make('HandManipulateBlock-v0')#('FetchReach-v1')
env.reset()
for _ in range(test_steps):
    env.render()
    env.step(env.action_space.sample()) # take a random action

env.close()