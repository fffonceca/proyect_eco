import gym # OpenAI Gym

# Inverted pendulum model
# For information about the action (u) and observation (x) space
# check:
# https://www.gymlibrary.ml/environments/mujoco/inverted_pendulum/

test_steps = 1000

env = gym.make('InvertedPendulum-v2')#('FetchReach-v1')
observation, info = env.reset(seed=0, return_info=True)

theta_ref = 0.0
e_k = 0.0
e_k_1 = 0.0
e_k_2 = 0.0
u_k_1 = 0.0 
T = 0.04 # obtained by estimating T = (Delta_theta/omega)
         #                          = (theta_k-theta_k-1)/theta_dot_k
theta_k = 0.0
theta_k_1 = 0.0
theta_filter_k = 0.0

Kp = 100.0
Ki = 98.1
Kd = 8.1



for _ in range(test_steps):
    env.render()
    
    # Option 1: random action
    #action = env.action_space.sample() # take a random action
    
    # Option 2: no action. Warning: this does not cancel internal disturbances
    action = [0.0] # u: system's manipulated variable
    
    # Option 3: PID control
    e_k_2 = e_k_1
    e_k_1 = e_k
    #e_k = theta_ref - theta_k
    theta_filter_k = 0.2*theta_k+0.8*theta_filter_k 
    e_k = theta_ref - theta_filter_k
    print(e_k)
    u_k = u_k_1 + Kp*(e_k-e_k_1) + Ki*e_k*T + Kd*(e_k-2*e_k_1+e_k_2)/T
    action = [-u_k]
    #print(u_k)
    
    # --- Step model ---
    theta_k_1 = theta_k
    observation, reward, done, info = env.step(action) 
    theta_k = observation[1]
    omega_k = observation[3]
    #print((theta_k-theta_k_1)/omega_k) # estimate the insternal sampling time
    #                                   # use the zero-input response
    #observation: [x theta x_dot theta_dot]
    #print(observation)
    #print(info) 
    
env.close()