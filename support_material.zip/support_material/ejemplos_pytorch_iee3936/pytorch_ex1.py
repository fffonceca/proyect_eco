# https://pytorch.org/tutorials/beginner/basics/intro.html
#
# If the following error occurs:
#
# OSError: [WinError 182] The operating system cannot run %1. Error loading "C:\Anaconda3\lib\site-packages\torch\lib\shm.dll" or one of its dependencies.
#
# Then run:
#
# conda install -c defaults intel-openmp -f
#
# See: https://github.com/pytorch/pytorch/issues/7579

import torch
from torch import nn                 # required to create a neural network class 
from torch.utils.data import Dataset # required for PyTorch datasets
from torchvision import datasets, transforms # required for PyTorch datasets
from torchvision.transforms import ToTensor, Lambda # required for PyTorch datasets
from torch.utils.data import DataLoader # required for PyTorch DataLoader


import numpy as np

import matplotlib.pyplot as plt



# 1. Tensors -- https://pytorch.org/tutorials/beginner/basics/tensorqs_tutorial.html

data = [[1., 2.],[3., 4.]]
x_data = torch.tensor(data)

print(x_data)

# We move our tensor to the GPU if available
# Get Device for Training
device = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Using {device} device")

if device == "cuda":
    x_data = x_data.to(device)
    print("GPU is available!")
    

y1 = x_data @ x_data.T  # @ is matrix multiplication
print(x_data)
print(y1)


# 2. Datasets and data loaders -- https://pytorch.org/tutorials/beginner/basics/data_tutorial.html
# https://pytorch.org/vision/stable/datasets.html

# - root is the path where the train/test data is stored,
# - train specifies training or test dataset,
# - download=True downloads the data from the internet if it’s not available at root.
# - transform and target_transform specify the feature and label transformations

# TRAINING DATA
training_data = datasets.FashionMNIST(
    root="data",
    train=True,
    download=True,
    transform=ToTensor()
)

# 3. (Data) transforms -- 
# https://pytorch.org/tutorials/beginner/basics/transforms_tutorial.html 
# ds = datasets.FashionMNIST(
    # root="data",
    # train=True,
    # download=True,
    # transform=ToTensor(),
    # target_transform=Lambda(lambda y: torch.zeros(10, dtype=torch.float).scatter_(0, torch.tensor(y), value=1))
#)


# TEST DATA
test_data = datasets.FashionMNIST(
    root="data",
    train=False,
    download=True,
    transform=ToTensor()
)


# Visualizing the dataset
# Label the dataset manually
labels_map = {
    0: "T-Shirt",
    1: "Trouser",
    2: "Pullover",
    3: "Dress",
    4: "Coat",
    5: "Sandal",
    6: "Shirt",
    7: "Sneaker",
    8: "Bag",
    9: "Ankle Boot",
}
figure = plt.figure(figsize=(8, 8))
cols, rows = 3, 3
for i in range(1, cols * rows + 1):
    sample_idx = torch.randint(len(training_data), size=(1,)).item()
    img, label = training_data[sample_idx]
    figure.add_subplot(rows, cols, i)
    plt.title(labels_map[label])
    plt.axis("off")
    plt.imshow(img.squeeze(), cmap="gray")
plt.show()


# Prepare data for training with DataLoaders
train_dataloader = DataLoader(training_data, batch_size=64, shuffle=True)
test_dataloader = DataLoader(test_data, batch_size=64, shuffle=True)

# Iterate through the DataLoader
# Display image and label.
train_features, train_labels = next(iter(train_dataloader))
print(f"Feature batch shape: {train_features.size()}")
print(f"Labels batch shape: {train_labels.size()}")
img = train_features[0].squeeze()
label = train_labels[0]
plt.imshow(img, cmap="gray")
plt.show()
print(f"Label: {label}")

# 4. Build the neural network -- https://pytorch.org/tutorials/beginner/basics/buildmodel_tutorial.html

# Define the class
# We define our neural network by subclassing nn.Module, and initialize the neural network layers in __init__. Every nn.Module subclass implements the operations on input data in the forward method.

class NeuralNetwork(nn.Module):
    def __init__(self):
        super(NeuralNetwork, self).__init__()
        self.flatten = nn.Flatten()
        self.linear_relu_stack = nn.Sequential(
            nn.Linear(28*28, 512),
            nn.ReLU(),
            nn.Linear(512, 512),
            nn.ReLU(),
            nn.Linear(512, 10),
        )

    def forward(self, x):
        x = self.flatten(x)
        logits = self.linear_relu_stack(x)
        return logits

# Create an instance of NeuralNetwork, and move it to the device, and print its structure.

model = NeuralNetwork().to(device)
print(model)

# To use the model, pass it the input data. This executes the model’s forward, along with some background operations. Do not call model.forward() directly!

# Calling the model on the input returns a 10-dimensional tensor with raw predicted values for each class. We get the prediction probabilities by passing it through an instance of the nn.Softmax module.

X = torch.rand(1, 28, 28, device=device)
print(X)
logits = model(X)
pred_probab = nn.Softmax(dim=1)(logits)
y_pred = pred_probab.argmax(1)
print(f"Predicted class: {y_pred}")
print(y_pred[0])

